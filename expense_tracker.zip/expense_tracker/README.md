# CLI Expense Tracker (Python, OOP)

A command-line expense tracker with file-based persistence (JSON). Data is saved after every change.

## Run
```bash
python main.py
```
Requires Python 3.9+. No external dependencies.

## Test
```bash
python -m unittest discover tests
```

## Structure
| File | Responsibility |
|------|----------------|
| `models.py` | `Transaction` (base) -> `Expense`, `Income` (inheritance); `Ledger` (business logic) |
| `storage.py` | `JsonStorage` - atomic JSON read/write |
| `cli.py` | `ExpenseTrackerCLI` - menu, input, output only |
| `main.py` | Wires everything together |

## OOP concepts used
- **Inheritance**: `Expense` and `Income` extend `Transaction`
- **Polymorphism**: `signed_amount`, `label`, `to_dict()` behave differently per subclass
- **Encapsulation**: the CLI never touches the file; `Ledger` saves via `JsonStorage`
- **Separation of concerns**: model vs storage vs CLI

## Features
Add expense/income, view, filter by type/category, delete, summary with per-category totals.
