import os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from models import Expense, Income, Ledger, Transaction
from storage import JsonStorage


class LedgerTests(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.TemporaryDirectory()
        self.path = os.path.join(self.dir.name, "t.json")

    def tearDown(self):
        self.dir.cleanup()

    def test_inheritance(self):
        self.assertTrue(issubclass(Expense, Transaction) and issubclass(Income, Transaction))

    def test_persistence_survives_restart(self):
        l1 = Ledger(JsonStorage(self.path))
        l1.add(Income(1000, "Pay", "Job"))
        l1.add(Expense(250.5, "Food", "groceries"))
        l2 = Ledger(JsonStorage(self.path))
        self.assertEqual(len(l2.transactions), 2)
        self.assertEqual(l2.balance(), 749.5)
        self.assertEqual(l2.expense_by_category(), {"Groceries": 250.5})

    def test_remove_saves(self):
        l1 = Ledger(JsonStorage(self.path))
        tx = l1.add(Expense(10, "x"))
        l1.remove(tx.id)
        self.assertEqual(len(Ledger(JsonStorage(self.path)).transactions), 0)

    def test_validation(self):
        with self.assertRaises(ValueError): Expense(-5, "bad")
        with self.assertRaises(ValueError): Expense(5, " ")
        with self.assertRaises(ValueError): Expense(5, "ok", tx_date="31-12-2025")


if __name__ == "__main__":
    unittest.main()
