from cli import ExpenseTrackerCLI
from models import Ledger
from storage import JsonStorage


def main():
    ledger = Ledger(JsonStorage("data/transactions.json"))
    try:
        ExpenseTrackerCLI(ledger).run()
    except (KeyboardInterrupt, EOFError):
        print("\nGoodbye! Your data is saved.")


if __name__ == "__main__":
    main()
