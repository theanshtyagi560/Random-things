"""CLI layer: only input/output and menu flow. All logic lives in models.py."""
from models import Expense, Income, Ledger


class ExpenseTrackerCLI:
    MENU = """
========== EXPENSE TRACKER ==========
1. Add expense
2. Add income
3. View all transactions
4. Filter transactions
5. Delete a transaction
6. Summary
0. Exit
"""

    def __init__(self, ledger: Ledger):
        self.ledger = ledger
        self.actions = {
            "1": self.add_expense,
            "2": self.add_income,
            "3": self.view_all,
            "4": self.filter_transactions,
            "5": self.delete,
            "6": self.summary,
        }

    # ---------- helpers ----------
    @staticmethod
    def _ask(prompt, default=None):
        suffix = f" [{default}]" if default else ""
        value = input(f"{prompt}{suffix}: ").strip()
        return value or default or ""

    def _show(self, items):
        if not items:
            print("No transactions found.")
            return
        print(f"\n{'ID':<9}{'Date':<12}{'Type':<9}{'Amount':>10}  {'Category/Src':<13}Description")
        print("-" * 70)
        for t in items:
            print(f"{t.id:<9}{t.date!s:<12}{t.kind:<9}{t.signed_amount:>10.2f}  {t.label:<13}{t.description}")

    # ---------- actions ----------
    def add_expense(self):
        tx = Expense(self._ask("Amount"), self._ask("Description"),
                     self._ask("Category", "General"), self._ask("Date YYYY-MM-DD (blank = today)"))
        self.ledger.add(tx)
        print(f"Saved expense {tx.id}.")

    def add_income(self):
        tx = Income(self._ask("Amount"), self._ask("Description"),
                    self._ask("Source", "Salary"), self._ask("Date YYYY-MM-DD (blank = today)"))
        self.ledger.add(tx)
        print(f"Saved income {tx.id}.")

    def view_all(self):
        self._show(self.ledger.list())

    def filter_transactions(self):
        kind = self._ask("Type (expense/income/blank for all)").lower() or None
        if kind not in (None, "expense", "income"):
            print("Type must be 'expense' or 'income'.")
            return
        category = self._ask("Category/Source (blank for all)") or None
        self._show(self.ledger.list(kind, category))

    def delete(self):
        self._show(self.ledger.list())
        if not self.ledger.transactions:
            return
        tx = self.ledger.remove(self._ask("ID to delete"))
        print(f"Deleted {tx.id} ({tx.description}).")

    def summary(self):
        print(f"\nTotal income : {self.ledger.total_income():>10.2f}")
        print(f"Total expense: {self.ledger.total_expense():>10.2f}")
        print(f"Balance      : {self.ledger.balance():>10.2f}")
        cats = self.ledger.expense_by_category()
        if cats:
            print("\nExpenses by category:")
            for name, amt in cats.items():
                print(f"  {name:<14}{amt:>10.2f}")

    # ---------- main loop ----------
    def run(self):
        while True:
            print(self.MENU)
            choice = input("Choose an option: ").strip()
            if choice == "0":
                print("Goodbye! Your data is saved.")
                return
            action = self.actions.get(choice)
            if not action:
                print("Invalid option, try again.")
                continue
            try:
                action()
            except (ValueError, KeyError) as e:
                print(f"Error: {e.args[0] if e.args else e}")
            except (KeyboardInterrupt, EOFError):
                print("\nCancelled.")
