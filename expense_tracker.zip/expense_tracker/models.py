"""Data model: no input() / print() here, so it can be reused and tested easily."""
from __future__ import annotations

import uuid
from datetime import date, datetime


class Transaction:
    """Base class for every money movement. Subclasses define the sign and extra field."""

    kind = "transaction"
    _registry: dict[str, type] = {}

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        Transaction._registry[cls.kind] = cls

    def __init__(self, amount, description, tx_date=None, tx_id=None):
        amount = float(amount)
        if amount <= 0:
            raise ValueError("Amount must be greater than 0.")
        description = str(description).strip()
        if not description:
            raise ValueError("Description cannot be empty.")
        self.id = tx_id or uuid.uuid4().hex[:8]
        self.amount = round(amount, 2)
        self.description = description
        self.date = self._parse_date(tx_date)

    @staticmethod
    def _parse_date(value) -> date:
        if value is None or value == "":
            return date.today()
        if isinstance(value, date):
            return value
        try:
            return datetime.strptime(str(value), "%Y-%m-%d").date()
        except ValueError:
            raise ValueError("Date must be in YYYY-MM-DD format.")

    @property
    def signed_amount(self) -> float:
        raise NotImplementedError

    @property
    def label(self) -> str:
        """Category / source text shown in tables."""
        return "-"

    def to_dict(self) -> dict:
        return {
            "type": self.kind,
            "id": self.id,
            "amount": self.amount,
            "description": self.description,
            "date": self.date.isoformat(),
        }

    @staticmethod
    def from_dict(data: dict) -> "Transaction":
        cls = Transaction._registry.get(data.get("type"))
        if cls is None:
            raise ValueError(f"Unknown transaction type: {data.get('type')!r}")
        return cls._build(data)

    @classmethod
    def _build(cls, data: dict) -> "Transaction":
        return cls(data["amount"], data["description"], data.get("date"), data.get("id"))

    def __str__(self):
        return f"{self.id}  {self.date}  {self.kind:<8} {self.signed_amount:>10.2f}  {self.label:<12} {self.description}"


class Expense(Transaction):
    kind = "expense"

    def __init__(self, amount, description, category="General", tx_date=None, tx_id=None):
        super().__init__(amount, description, tx_date, tx_id)
        self.category = (str(category).strip() or "General").title()

    @property
    def signed_amount(self) -> float:
        return -self.amount

    @property
    def label(self) -> str:
        return self.category

    def to_dict(self) -> dict:
        data = super().to_dict()
        data["category"] = self.category
        return data

    @classmethod
    def _build(cls, data):
        return cls(data["amount"], data["description"], data.get("category", "General"),
                   data.get("date"), data.get("id"))


class Income(Transaction):
    kind = "income"

    def __init__(self, amount, description, source="Other", tx_date=None, tx_id=None):
        super().__init__(amount, description, tx_date, tx_id)
        self.source = (str(source).strip() or "Other").title()

    @property
    def signed_amount(self) -> float:
        return self.amount

    @property
    def label(self) -> str:
        return self.source

    def to_dict(self) -> dict:
        data = super().to_dict()
        data["source"] = self.source
        return data

    @classmethod
    def _build(cls, data):
        return cls(data["amount"], data["description"], data.get("source", "Other"),
                   data.get("date"), data.get("id"))


class Ledger:
    """Holds all transactions and persists via the storage object after EVERY change."""

    def __init__(self, storage):
        self.storage = storage
        self.transactions: list[Transaction] = [
            Transaction.from_dict(d) for d in storage.load()
        ]

    def _save(self):
        self.storage.save([t.to_dict() for t in self.transactions])

    def add(self, tx: Transaction) -> Transaction:
        self.transactions.append(tx)
        self._save()
        return tx

    def remove(self, tx_id: str) -> Transaction:
        for i, tx in enumerate(self.transactions):
            if tx.id == tx_id:
                removed = self.transactions.pop(i)
                self._save()
                return removed
        raise KeyError(f"No transaction with id {tx_id!r}.")

    def list(self, kind=None, category=None):
        items = sorted(self.transactions, key=lambda t: t.date)
        if kind:
            items = [t for t in items if t.kind == kind]
        if category:
            items = [t for t in items if t.label.lower() == category.strip().lower()]
        return items

    def total_income(self) -> float:
        return sum(t.amount for t in self.transactions if isinstance(t, Income))

    def total_expense(self) -> float:
        return sum(t.amount for t in self.transactions if isinstance(t, Expense))

    def balance(self) -> float:
        return round(self.total_income() - self.total_expense(), 2)

    def expense_by_category(self) -> dict[str, float]:
        out: dict[str, float] = {}
        for t in self.transactions:
            if isinstance(t, Expense):
                out[t.category] = round(out.get(t.category, 0) + t.amount, 2)
        return dict(sorted(out.items(), key=lambda kv: -kv[1]))
