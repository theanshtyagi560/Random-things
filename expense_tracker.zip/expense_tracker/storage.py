"""File persistence (JSON). Swap this class for SQLite/CSV without touching models or CLI."""
import json
import os
import shutil
from pathlib import Path


class JsonStorage:
    def __init__(self, path="data/transactions.json"):
        self.path = Path(path)

    def load(self) -> list[dict]:
        if not self.path.exists():
            return []
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return data if isinstance(data, list) else []
        except json.JSONDecodeError:
            backup = self.path.with_suffix(".corrupt.json")
            shutil.copy(self.path, backup)
            print(f"Warning: data file was corrupted. Backup saved to {backup}. Starting fresh.")
            return []

    def save(self, records: list[dict]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(records, f, indent=2)
        os.replace(tmp, self.path)  # atomic: no half-written file if the app crashes
