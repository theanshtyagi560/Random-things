from decimal import Decimal

from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse

from .models import Transaction


class AuthTests(TestCase):
    def test_dashboard_requires_login(self):
        r = self.client.get(reverse("dashboard"))
        self.assertEqual(r.status_code, 302)
        self.assertIn("/accounts/login/", r.url)

    def test_register_logs_user_in(self):
        r = self.client.post(reverse("register"), {
            "username": "ansh", "password1": "Str0ngPass!234", "password2": "Str0ngPass!234"})
        self.assertRedirects(r, reverse("dashboard"))
        self.assertTrue(User.objects.filter(username="ansh").exists())

    def test_login_and_logout(self):
        User.objects.create_user("ansh", password="pw12345!x")
        self.assertTrue(self.client.login(username="ansh", password="pw12345!x"))
        self.assertEqual(self.client.get(reverse("dashboard")).status_code, 200)
        self.client.post(reverse("logout"))
        self.assertEqual(self.client.get(reverse("dashboard")).status_code, 302)


class TransactionTests(TestCase):
    def setUp(self):
        self.u1 = User.objects.create_user("a", password="pw12345!x")
        self.u2 = User.objects.create_user("b", password="pw12345!x")
        self.client.login(username="a", password="pw12345!x")

    def test_create_and_totals(self):
        self.client.post(reverse("add"), {"kind": "income", "amount": "1000", "description": "Pay",
                                          "category": "job", "date": "2026-10-01"})
        self.client.post(reverse("add"), {"kind": "expense", "amount": "250.50", "description": "Food",
                                          "category": "food", "date": "2026-10-02"})
        r = self.client.get(reverse("dashboard"))
        self.assertEqual(r.context["balance"], Decimal("749.50"))
        self.assertEqual(list(r.context["by_category"]), [{"category": "Food", "total": Decimal("250.50")}])

    def test_invalid_amount_rejected(self):
        r = self.client.post(reverse("add"), {"kind": "expense", "amount": "-5", "description": "x",
                                              "category": "x", "date": "2026-10-02"})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(Transaction.objects.count(), 0)

    def test_users_cannot_access_each_others_data(self):
        tx = Transaction.objects.create(user=self.u2, kind="expense", amount=10, description="secret")
        self.assertEqual(self.client.get(reverse("edit", args=[tx.pk])).status_code, 404)
        self.assertEqual(self.client.post(reverse("delete", args=[tx.pk])).status_code, 404)
        self.assertNotIn(tx, self.client.get(reverse("dashboard")).context["transactions"])

    def test_edit_and_delete(self):
        tx = Transaction.objects.create(user=self.u1, kind="expense", amount=10, description="old")
        self.client.post(reverse("edit", args=[tx.pk]), {"kind": "expense", "amount": "20",
                         "description": "new", "category": "misc", "date": "2026-10-03"})
        tx.refresh_from_db()
        self.assertEqual((tx.description, tx.amount), ("new", Decimal("20.00")))
        self.client.post(reverse("delete", args=[tx.pk]))
        self.assertFalse(Transaction.objects.filter(pk=tx.pk).exists())

    def test_filter_by_kind(self):
        Transaction.objects.create(user=self.u1, kind="income", amount=5, description="i")
        Transaction.objects.create(user=self.u1, kind="expense", amount=5, description="e")
        r = self.client.get(reverse("dashboard"), {"kind": "income"})
        self.assertEqual([t.description for t in r.context["transactions"]], ["i"])
