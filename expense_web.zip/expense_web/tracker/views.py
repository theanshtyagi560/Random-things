from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db.models import Sum
from django.shortcuts import redirect, render
from django.urls import reverse_lazy
from django.views.generic import CreateView, DeleteView, ListView, UpdateView

from .forms import TransactionForm
from .models import Transaction


def register(request):
    if request.user.is_authenticated:
        return redirect("dashboard")
    form = UserCreationForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        login(request, user)
        messages.success(request, "Account created. Welcome!")
        return redirect("dashboard")
    return render(request, "registration/register.html", {"form": form})


class OwnedMixin(LoginRequiredMixin):
    """Every query is scoped to the logged-in user, so nobody can touch others' data."""

    def get_queryset(self):
        return Transaction.objects.filter(user=self.request.user)


class Dashboard(OwnedMixin, ListView):
    template_name = "tracker/dashboard.html"
    context_object_name = "transactions"
    paginate_by = 15

    def get_queryset(self):
        qs = super().get_queryset()
        kind = self.request.GET.get("kind")
        category = self.request.GET.get("category", "").strip()
        if kind in (Transaction.EXPENSE, Transaction.INCOME):
            qs = qs.filter(kind=kind)
        if category:
            qs = qs.filter(category__iexact=category)
        return qs

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        mine = Transaction.objects.filter(user=self.request.user)
        income = mine.filter(kind=Transaction.INCOME).aggregate(t=Sum("amount"))["t"] or 0
        expense = mine.filter(kind=Transaction.EXPENSE).aggregate(t=Sum("amount"))["t"] or 0
        ctx.update(
            total_income=income,
            total_expense=expense,
            balance=income - expense,
            by_category=mine.filter(kind=Transaction.EXPENSE)
            .values("category").annotate(total=Sum("amount")).order_by("-total"),
            selected_kind=self.request.GET.get("kind", ""),
            selected_category=self.request.GET.get("category", ""),
        )
        return ctx


class TransactionCreate(OwnedMixin, CreateView):
    form_class = TransactionForm
    template_name = "tracker/transaction_form.html"
    success_url = reverse_lazy("dashboard")
    extra_context = {"title": "Add transaction"}

    def form_valid(self, form):
        form.instance.user = self.request.user
        messages.success(self.request, "Transaction added.")
        return super().form_valid(form)


class TransactionUpdate(OwnedMixin, UpdateView):
    form_class = TransactionForm
    template_name = "tracker/transaction_form.html"
    success_url = reverse_lazy("dashboard")
    extra_context = {"title": "Edit transaction"}

    def form_valid(self, form):
        messages.success(self.request, "Transaction updated.")
        return super().form_valid(form)


class TransactionDelete(OwnedMixin, DeleteView):
    template_name = "tracker/transaction_confirm_delete.html"
    success_url = reverse_lazy("dashboard")

    def form_valid(self, form):
        messages.success(self.request, "Transaction deleted.")
        return super().form_valid(form)
