from decimal import Decimal

from django.contrib.auth.models import User
from django.core.validators import MinValueValidator
from django.db import models
from django.utils import timezone


class Transaction(models.Model):
    EXPENSE = "expense"
    INCOME = "income"
    KIND_CHOICES = [(EXPENSE, "Expense"), (INCOME, "Income")]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="transactions")
    kind = models.CharField(max_length=7, choices=KIND_CHOICES, default=EXPENSE)
    amount = models.DecimalField(
        max_digits=12, decimal_places=2, validators=[MinValueValidator(Decimal("0.01"))]
    )
    description = models.CharField(max_length=200)
    category = models.CharField(max_length=50, default="General")
    date = models.DateField(default=timezone.localdate)

    class Meta:
        ordering = ["-date", "-id"]

    def save(self, *args, **kwargs):
        self.category = (self.category or "General").strip().title()
        super().save(*args, **kwargs)

    @property
    def signed_amount(self):
        return self.amount if self.kind == self.INCOME else -self.amount

    def __str__(self):
        return f"{self.get_kind_display()} {self.amount} - {self.description}"
