from django.urls import path

from . import views

urlpatterns = [
    path("", views.Dashboard.as_view(), name="dashboard"),
    path("register/", views.register, name="register"),
    path("add/", views.TransactionCreate.as_view(), name="add"),
    path("<int:pk>/edit/", views.TransactionUpdate.as_view(), name="edit"),
    path("<int:pk>/delete/", views.TransactionDelete.as_view(), name="delete"),
]
